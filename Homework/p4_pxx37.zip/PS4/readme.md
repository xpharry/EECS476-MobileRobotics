# example use

	roslaunch gazebo_ros empty_world.launch

	roslaunch mobot_urdf mobot_w_lidar.launch

	rosrun mobot_lidar_alarm mobot_lidar_alarm

	rosrun mobot_action_server mobot_action_server_w_fdbk

	rosrun mobot_action_server mobot_action_client
