# my gmapping

https://youtu.be/blJj9HvjlBc

# my robot moving in known map

https://youtu.be/WLTDUp6QHRg

# my robot wandering for gmapping

https://youtu.be/ggXYbUHMpR0
